const express = require('express');
const path = require('path');
const app = express();

app.get('/', (req,res) => {
    res.sendFile(path.resolve(__dirname, 'index.html'));
});

app.get('/registro', (req,res) => {
    res.sendFile(path.resolve(__dirname, 'registro.html'));
});

app.get('/login', (req,res) => {
    res.sendFile(path.resolve(__dirname, 'login.html'));
});

app.get('/afegir', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'afegir.html'));
});

app.get('/llistat', (req, res) =>{
    res.sendFile(path.resolve(__dirname, "llistat.html"));
});

app.listen(3000);