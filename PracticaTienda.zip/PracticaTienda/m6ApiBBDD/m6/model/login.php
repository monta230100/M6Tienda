<?php
    Class login {
        private $db;
        private $user;
        
        public function __construct(){
            require_once("./model/connexio.php");
            $this->db=Connexio::connectar();
            $this->user=array();
        }

        public function login_cliente($user){
            $consulta = "SELECT dni FROM cliente WHERE dni='$user->dni' and contrasena='$user->contrasena';";
            $response = $this->db->query($consulta);
            $dni = $response->fetchAll(PDO::FETCH_ASSOC);
            return $dni[0]["dni"];
        }
    }
?>