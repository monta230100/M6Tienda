<?php
    Class register {
        private $db;
        private $user;

        public function __construct(){
            require_once("./model/connexio.php");
            $this->db=Connexio::connectar();
            $this->user=array();
        }

        public function register_user($user){
            if($user){
                $consulta = "INSERT INTO cliente (dni, nombre, apellidos, email, contrasena, telefon, adreca) VALUES ('$user->dni', '$user->nombre', '$user->apellidos', '$user->correo', '$user->contrasena', '$user->telefon', '$user->adreca');";
                $res_insert = $this->db->query($consulta);
                return $user->dni;
            }
        }
    }
?>