<?php
    Class productos_m {
        private $db;
        private $productos;
        
        public function __construct(){
            require_once("./model/connexio.php");
            $this->db=Connexio::connectar();
            $this->productos=array();
        }

        public function getAllProductos(){
            $consulta = "SELECT * FROM productos;";
            $result = $this->db->query($consulta);
            while ($fila=$result->fetch(PDO::FETCH_ASSOC)){
                $data = file_get_contents($fila["img"]);
                $fila["img"] = "data:image/jpeg;base64,".base64_encode($data);
                $this->productos[]=$fila;
            }
            return $this->productos;
        }

        public function setProducto($body){
            $target_dir = "/var/www/m6/model/Imagenes/";
            $target_file = $target_dir . basename($_FILES["img"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            
            // Check if image file is a actual image or fake image
              $check = getimagesize($_FILES["img"]["tmp_name"]);
              if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
              } else {
                echo "File is not an image.";
                $uploadOk = 0;
              }
            // Check if file already exists
            if (file_exists($target_file)) {
              echo "Sorry, file already exists.";
              $uploadOk = 0;
            }
            
            // Check file size
            if ($_FILES["img"]["size"] > 500000) {
              echo "Sorry, your file is too large.";
              $uploadOk = 0;
            }
            
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
              echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
              $uploadOk = 0;
            }
            
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
              echo "Sorry, your file was not uploaded.";
            // if everything is ok, try to upload file
            } else {
                move_uploaded_file($_FILES["img"]["tmp_name"], $target_file);
            }
            $nombre = $_POST['nombre'];
            $descripcion = $_POST['descripcion'];
            $preu = $_POST['preu'];
            $categoria = $_POST['categoria'];
            $id_cliente = $_POST['id_cliente'];

            $consulta = "INSERT INTO productos (nombre, descripcion, preu, categoria, img, id_cliente) VALUES ('$nombre', '$descripcion', '$preu', '$categoria', '$target_file', '$id_cliente');";
            $res_insert = $this->db->query($consulta);
            return $res_insert;
        }

        public function deleteProducto($id){
            var_dump($id);
            $consulta = "DELETE FROM productos WHERE ID=".$id.";";
            $res_insert = $this->db->query($consulta);
            return $res_insert;
        }

        public function getProductosFiltrados($options){
            unset($options['url']);
            $last_key = end(array_keys($options));
            $consulta = "SELECT * FROM productos WHERE ";
            foreach($options as $param => $value){
                if($last_key == $param){
                    $consulta = $consulta.$param." LIKE'%".$value."%';";
                }else{
                    $consulta = $consulta.$param." LIKE'%".$value."%' and ";
                }
            }
            $result = $this->db->query($consulta);
            while ($fila=$result->fetch(PDO::FETCH_ASSOC)){
                $this->recetas[]=$fila;
            }
            return $this->recetas;
        }
    }
?>