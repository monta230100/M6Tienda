<?php
    require_once "./model/productos_m.php";
    class productos{    
        public function __construct($params, $body){
            $method = array_shift($params);
            switch ($method){
                case "GET":
                    $this->getProductos();
                    break;
                case "POST":
                    $this->createProducto($body);
                    break;
                case "DELETE":
                    $this->deleteProducto($params);
                    break;
                default:
                    $this->notImplementedMethodReceta($params, $body, $method);
                    break;
            }

        }

        private function getProductos(){
            $model = new productos_m();
            $results = array();
            foreach($_GET as $getParam => $value){
                $results[$getParam] = $value;
            }
            if(count($results)>1){
                $recetas = $model->getProductosFiltrados($results);
            }else{
                $recetas = $model->getAllProductos();
            }
            require_once("./vista/recetas_v.php");
        }

        private function createProducto($body){
            $model = new productos_m();
            $recetas = $model->setProducto($body);
            http_response_code(201);
            require_once("./vista/recetas_v.php");
        }

        private function deleteProducto($params){ 
            $model = new productos_m();
            if (count($params) == 0){
                echo "bad request";
            }else{
                $recetas = $model->deleteProducto($params[1]);
            }
            http_response_code(204);
            require_once("./vista/recetas_v.php");
        }

        private function notImplementedMethodReceta($params, $method){
            header('Content-Type: application/json');
            echo json_encode(array("error"=> "Not implemented method!", "method" => $method, "params" => $params)).PHP_EOL;
        }

    }
?>