<?php
    class Error_c{
        public function __construct($params){
            var_dump($params);
        }
    }
?>