<?php
    
    class registro{    
        public function __construct($params, $body){
            $metode = array_shift($params);
            if($params[1] == "login"){
                $this->user_login($body);
            }else{
                $this->user_register($body);
            }
        }

        private function user_login($body){
            require_once("./model/login.php");
            $model = new login();
            $login_user = $model->login_cliente($body);
            http_response_code(201);
            require_once("./vista/user_login_v.php");
        }

        private function user_register($body){
            require_once("./model/register.php");
            $model = new register();
            $register_user = $model->register_user($body);
            http_response_code(201);
            require_once("./vista/user_register_v.php");
        }
    }
?>