<?php
    header("Content-Type: application/json; charset=utf-8");
    $response = array();
    if($register_user){
        $response["message"] = $register_user;
    }else{
        $response["message"] = "KO";
    }
    echo json_encode($body);
?>