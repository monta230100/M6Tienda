<?php
    header("Content-Type: application/json; charset=utf-8");
    $response = array();
    if($login_user){
        $response["message"] = $login_user;
    }else{
        $response["message"] = "KO";
    }
    echo json_encode($response);
?>