<?php
    header("Content-Type: application/json; charset=utf-8");
    $response = array();
    if($recetas){
        $response["message"] = $recetas;
    }else{
        $response["message"] = "KO";
    }
    echo json_encode($response);
?>